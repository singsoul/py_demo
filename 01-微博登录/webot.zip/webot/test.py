# encoding=utf8
from bot import Webot
import requests


def main():
    mybot = Webot().start()

if __name__ == '__main__':
    main()
